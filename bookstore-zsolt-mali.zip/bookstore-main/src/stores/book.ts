import { IBook, IBookState, IBookSort } from "../types";
import { defineStore } from "pinia";
export const useBookStore = defineStore("bookStore", {
  state: (): IBookState => ({
    books: [] as IBook[],
    sortBy: {
      sortField: "name",
      sortMode: "asc",
    } as IBookSort,
  }),
  getters: {
    hasBooks(state: IBookState): boolean {
      return (state.books.length ?? 0) != 0 ? true : false;
    },
    hasSelectedBooks(state: IBookState): boolean {
      return state.books.filter((item: IBook): boolean => item.selected)
        .length > 0
        ? true
        : false;
    },
  },
  actions: {
    addBook(book: IBook | null): IBook {
      if (book === null) {
        book = {
          id: this.getMaxId() + 1,
          name: "",
          price: 0,
          category: "Best Seller",
          description: "",
          selected: false,
        };
      }
      this.books.push(book);
      //added new item should sort the books
      this.sortBooks();
      return book;
    },
    getMaxId: function (): number {
      return this.books.reduce(
        (maxId: number, book: IBook): number =>
          maxId > book.id ? maxId : book.id,
        0,
      );
    },
    saveBook(book: IBook): IBook {
      if (book.id === 0) {
        book.id = this.getMaxId() + 1;
        this.books.push(book);
        //added new item should sort the books
        this.sortBooks();
      } else {
        let bookIndex = this.books.findIndex(
          (item: IBook): boolean => item.id === book.id,
        );
        if (bookIndex !== -1) {
          this.books[bookIndex] = { ...book };
          //item changed let's sort
          this.sortBooks();
          return this.books[bookIndex];
        }
      }
      return book;
    },
    deleteBook(book: IBook): void {
      this.books = this.books.filter(
        (item: IBook): boolean => item.id !== book.id,
      );
      //item changed let's sort
      this.sortBooks();
    },
    deleteSelected(): void {
      this.books = this.books.filter(
        (item: IBook): boolean => item.selected === false,
      );
      //item changed let's sort
      this.sortBooks();
    },
    sortBooks(): void {
      let sortField = this.sortBy.sortField as
        | "id"
        | "name"
        | "price"
        | "category";
      let sortMode = this.sortBy.sortMode;
      this.books.sort((a: IBook, b: IBook): 1 | -1 | 0 => {
        if (sortMode === "asc") {
          return a[sortField] > b[sortField]
            ? 1
            : b[sortField] > a[sortField]
              ? -1
              : 0;
        } else {
          return b[sortField] > a[sortField]
            ? 1
            : a[sortField] > b[sortField]
              ? -1
              : 0;
        }
      });
    },
  },
});
