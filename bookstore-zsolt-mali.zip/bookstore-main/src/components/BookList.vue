<script setup lang="ts">
import { ref } from "vue";
import { useBookStore } from "../stores/book";
import BookForm from "./BookForm.vue";
import { IBook } from "../types";
const store = useBookStore();
const bookformRef = ref();
const addBook = (): void => {
  // let book = store.addBook(null);
  editBook(null);
};
const editBook = (book: IBook | null): void => {
  bookformRef.value.openDialog(book);
};
const saveBook = (book: IBook): void => {
  store.saveBook(book);
};
const deleteBook = (book: IBook): void => {
  store.deleteBook(book);
};
const deleteSelected = (): void => {
  store.deleteSelected();
};
</script>

<template>
  <div class="my-2">
    <a class="border p-2 rounded bg-green-300" @click.prevent="addBook"
      >+ Add Book</a
    >
  </div>
  <div class="flex justify-between items-center">
    <h1 class="p-2">Book List</h1>
    <div class="flex justify-end items-center">
      Sort By:
      <select
        name="sortBy"
        v-model="store.sortBy.sortField"
        @change="store.sortBooks"
        class="p-2 mx-2"
      >
        <option value="id">Id</option>
        <option value="name">Name</option>
        <option value="price">Price</option>
        <option value="category">Category</option>
      </select>

      <select
        name="sortMode"
        v-model="store.sortBy.sortMode"
        @change="store.sortBooks"
        class="p-2 mx-2"
      >
        <option value="asc">Asc</option>
        <option value="desc">Desc</option>
      </select>
    </div>
  </div>
  <table v-if="store.hasBooks">
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Category</th>
        <th>Price</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="book in store.books" :key="book.id">
        <td class="p-2">
          <input type="checkbox" v-model="book.selected" /> {{ book.id }}
        </td>
        <td class="p-2" @click.prevent="editBook(book)">{{ book.name }}</td>
        <td class="p-2" @click.prevent="editBook(book)">{{ book.category }}</td>
        <td class="p-2" @click.prevent="editBook(book)">${{ book.price }}</td>
        <td class="p-2">
          <a
            class="text-red-600 hover:text-red-800"
            @click.prevent="deleteBook(book)"
            >Delete</a
          >
        </td>
      </tr>
    </tbody>
  </table>
  <div v-else>No book in the list. Please add one using the button above.</div>
  <div v-if="store.hasSelectedBooks">
    <button
      class="border rounded p-2 bg-red-500 text-white"
      @click="deleteSelected"
    >
      Delete Selected Books
    </button>
  </div>
  <BookForm
    ref="bookformRef"
    @on-close-dialog="
      () => {
        /*do nothing here;*/
      }
    "
    @on-save-book="saveBook"
    @on-delete-book="deleteBook"
  />
</template>
