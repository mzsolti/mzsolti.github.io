<script setup lang="ts">
import { ref } from "vue";
import { IBook } from "../types";
import Dialog from "primevue/dialog";
const book = ref<IBook>({
  id: 0,
  name: "",
  price: 0,
  category: "Best Seller",
  description: "",
  selected: false,
});
const showDialog = ref(false);
const emit = defineEmits(["on-close-dialog", "on-save-book", "on-delete-book"]);
const closeDialog = (success: boolean): void => {
  showDialog.value = false;
  emit("on-close-dialog", success);
};
const openDialog = (l_book: IBook | null) => {
  showDialog.value = true;
  if (l_book !== null) {
    book.value = { ...l_book };
  }
};
const saveBook = () => {
  //emit save the book event - either new or update one
  emit("on-save-book", { ...book.value });
  closeDialog(true);
  //reset book value
  book.value = {
    id: 0,
    name: "",
    price: 0,
    category: "Best Seller",
    description: "",
    selected: false,
  };
};
const deleteBook = (): void => {
  //emit delete book event
  emit("on-delete-book", book.value);
  closeDialog(true);
};
defineExpose({
  openDialog,
});
</script>
<template>
  <Dialog
    :visible="showDialog"
    modal
    header="Book Details"
    :style="{ width: '75vw' }"
    @update:visible="closeDialog(false)"
  >
    <table class="table-auto w-full">
      <tbody>
        <tr>
          <td class="font-bold align-top">Name :</td>
          <td class="p-2">
            <input
              class="border rounded p-1 w-full"
              type="text"
              name="bookname"
              v-model="book.name"
            />
          </td>
        </tr>
        <tr>
          <td class="font-bold align-top">Price :</td>
          <td class="p-2">
            <input
              class="border rounded p-1 w-full"
              type="number"
              name="price"
              v-model="book.price"
            />
          </td>
        </tr>
        <tr>
          <td class="font-bold align-top">Category :</td>
          <td class="p-2">
            <input
              class="border rounded p-1 w-full"
              type="text"
              name="category"
              v-model="book.category"
            />
          </td>
        </tr>
        <tr>
          <td class="font-bold align-top">Description :</td>
          <td class="p-2">
            <textarea
              class="border rounded p-1 w-full"
              name="description"
              v-model="book.description"
            />
          </td>
        </tr>
      </tbody>
    </table>
    <div class="p-2 text-center flex gap-3 justify-center">
      <button
        class="bg-green-200 border rounded p-2 font-bold"
        @click.prevent="saveBook"
      >
        Save
      </button>
      <button
        class="bg-red-500 border rounded p-2 font-bold text-white"
        @click.prevent="deleteBook"
        v-show="book.id !== 0"
      >
        Delete
      </button>
      <button
        class="bg-gray-200 border rounded p-2 font-bold"
        @click.prevent="
          () => {
            closeDialog(false);
          }
        "
      >
        Cancel
      </button>
    </div>
  </Dialog>
</template>
