export interface IBook {
  id: number;
  name: string;
  price: number;
  category: string;
  description: string;
  selected: boolean;
}
export interface IBookState {
  books: IBook[];
  sortBy: IBookSort;
}
export interface IBookSort {
  sortField: string;
  sortMode: "asc" | "desc";
}
