<script setup>
import BookList from "./components/BookList.vue";
</script>

<template>
  <div class="container mx-auto px-4">
    <BookList />
  </div>
</template>
