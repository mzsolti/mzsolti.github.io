import { createApp } from "vue";
import PrimeVue from "primevue/config";
import { createPinia } from "pinia";
import "./assets/style.scss";
import App from "./App.vue";

const pinia = createPinia();
const app = createApp(App);
app.use(PrimeVue);
app.use(pinia);
app.mount("#app");
